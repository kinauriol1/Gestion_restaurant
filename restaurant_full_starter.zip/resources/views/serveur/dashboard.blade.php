@extends('layouts.app')

@section('title', 'Tableau de bord Serveur')

@section('content')
    <p>Bienvenue sur l'espace serveur !</p>
@endsection
