@extends('layouts.app')

@section('title', 'Tableau de bord Cuisinier')

@section('content')
    <p>Bienvenue sur l'espace cuisinier !</p>
@endsection
