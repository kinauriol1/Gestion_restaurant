@extends('layouts.app')

@section('title', 'Tableau de bord Client')

@section('content')
    <p>Bienvenue sur l'espace client !</p>
@endsection
