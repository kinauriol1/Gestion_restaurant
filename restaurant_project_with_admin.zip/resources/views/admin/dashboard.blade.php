@extends('layouts.app')

@section('title', 'Tableau de bord Admin')

@section('content')
    <p>Bienvenue sur l'espace admin !</p>
@endsection
