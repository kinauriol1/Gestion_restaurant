@extends('layouts.app')

@section('title', 'Tableau de bord Livreur')

@section('content')
    <p>Bienvenue sur l'espace livreur !</p>
@endsection
