@extends('layouts.app')

@section('title', 'Tableau de bord Caissier')

@section('content')
    <p>Bienvenue sur l'espace caissier !</p>
@endsection
