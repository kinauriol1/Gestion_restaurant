<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    public function create(): View
    {
        return view('auth.login');
    }

    public function store(Request $request): RedirectResponse
    {
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();
            $user = Auth::user();

            switch ($user->role->nom) {
                case 'admin':
                    return redirect('/admin');
                case 'client':
                    return redirect('/client/menu');
                case 'serveur':
                    return redirect('/serveur/commandes');
                case 'cuisinier':
                    return redirect('/cuisinier/preparations');
                case 'caissier':
                    return redirect('/caissier/paiements');
                case 'livreur':
                    return redirect('/livreur/livraisons');
                default:
                    return redirect('/');
            }
        }

        return back()->withErrors([
            'email' => 'Les informations fournies sont incorrectes.',
        ]);
    }

    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/');
    }
}
